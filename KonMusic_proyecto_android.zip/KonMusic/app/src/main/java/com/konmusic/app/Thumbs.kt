package com.konmusic.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache

object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)

    fun load(ctx: Context, item: Item): Bitmap? {
        val key = item.uri.toString()
        cache.get(key)?.let { return it }
        val r = MediaMetadataRetriever()
        var bmp: Bitmap? = null
        try {
            r.setDataSource(ctx, item.uri)
            bmp = if (item.video) {
                r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } else {
                r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            }
            bmp = bmp?.let {
                val w = 240
                val h = (240f * it.height / it.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(it, w, h, true)
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        bmp?.let { cache.put(key, it) }
        return bmp
    }
}

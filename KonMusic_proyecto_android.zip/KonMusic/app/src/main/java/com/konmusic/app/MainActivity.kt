package com.konmusic.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else if (Build.VERSION.SDK_INT < 29) {
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2
            )
        }
        val shared = if (intent?.action == Intent.ACTION_SEND) {
            Regex("https?://\\S+").find(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")?.value
        } else null
        setContent { KonTheme { App(shared) } }
    }
}

@Composable
fun App(sharedUrl: String?) {
    var tab by remember { mutableIntStateOf(if (sharedUrl != null) 1 else 0) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { Header() },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text("Biblioteca") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Add, null) }, label = { Text("Descargar") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            if (tab == 0) LibraryScreen() else DownloadScreen(sharedUrl)
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(40.dp).clip(CircleShape))
        Spacer(Modifier.width(12.dp))
        Text("KonMusic", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    val ver = Downloads.version.intValue
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Item?>(null) }
    val all = remember(ver) { Downloads.library() }
    val shown = all.filter { f ->
        (filter == 0 || (filter == 1 && f.video) || (filter == 2 && !f.video)) &&
            f.name.contains(query, ignoreCase = true)
    }
    val active = Downloads.jobs.filter { it.active }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java).setData(it)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar en tu biblioteca") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Todo", "Videos", "Música").forEachIndexed { i, t ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) })
                }
            }
        }
        if (active.isNotEmpty()) {
            item { Text("Descargas activas", fontWeight = FontWeight.Bold) }
            items(active, key = { it.id }) { JobCard(it) }
        }
        item {
            val total = all.sumOf { it.size }
            Text(
                "${all.size} archivos · ${Formatter.formatFileSize(ctx, total)}",
                fontSize = 13.sp, color = Color.Gray
            )
        }
        items(shown, key = { it.uri.toString() }) { f ->
            FileRow(
                f,
                onPlay = {
                    ctx.startActivity(
                        Intent(ctx, PlayerActivity::class.java).setData(f.uri)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                },
                onShare = { share(ctx, f) },
                onDelete = { toDelete = f }
            )
        }
        if (shown.isEmpty()) {
            item { Text("Aún no hay archivos. Ve a Descargar para añadir el primero.", color = Color.Gray) }
        }
        item {
            OutlinedButton(
                onClick = { picker.launch(arrayOf("video/*", "audio/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Abrir archivo del teléfono") }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Eliminar") },
            text = { Text(f.name) },
            confirmButton = {
                TextButton(onClick = {
                    if (!Downloads.deleteItem(f)) Toast.makeText(ctx, "No se pudo eliminar", Toast.LENGTH_SHORT).show()
                    Downloads.version.intValue++; toDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

fun share(ctx: Context, f: Item) {
    val uri = if (f.file != null) FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f.file) else f.uri
    val i = Intent(Intent.ACTION_SEND).setType("*/*")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
fun FileRow(f: Item, onPlay: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val video = f.video
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onPlay),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            val thumb by produceState<Bitmap?>(null, f.uri) {
                value = withContext(Dispatchers.IO) { Thumbs.load(ctx, f) }
            }
            Box(
                Modifier.size(72.dp).clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                val b = thumb
                if (b != null) {
                    Image(
                        b.asImageBitmap(), null,
                        Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                    )
                    if (video) {
                        Text("▶", color = Color.White, fontSize = 20.sp)
                    }
                } else {
                    Text(if (video) "🎬" else "🎵", fontSize = 26.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    "${f.ext.uppercase()} · ${Formatter.formatFileSize(ctx, f.size)}",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
            IconButton(onClick = onShare) { Icon(Icons.Default.Share, null) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null) }
        }
    }
}

@Composable
fun JobCard(j: Job) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(j.label, fontWeight = FontWeight.Bold)
                    Text(j.url, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.Gray)
                }
                if (j.active) {
                    IconButton(onClick = { Downloads.cancel(j.id) }) { Icon(Icons.Default.Close, null) }
                }
            }
            if (j.active) {
                LinearProgressIndicator(progress = { j.progress }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            Text(
                j.status + if (j.active && j.progress > 0f) " ${(j.progress * 100).toInt()}%" else "",
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DownloadScreen(shared: String?) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(shared ?: "") }
    var audio by remember { mutableStateOf(false) }
    var height by remember { mutableIntStateOf(720) }
    var fmt by remember { mutableStateOf("mp3") }
    var kbps by remember { mutableIntStateOf(192) }
    val jobs = Downloads.jobs.reversed()
    var hasCookies by remember { mutableStateOf(Downloads.cookiesFile.exists()) }
    val cookiePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        u?.let {
            try {
                ctx.contentResolver.openInputStream(it)?.use { i ->
                    Downloads.cookiesFile.outputStream().use { o -> i.copyTo(o) }
                }
                hasCookies = true
                Toast.makeText(ctx, "Cookies cargadas", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(ctx, "No se pudo leer el archivo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Enlace del video o música") },
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    TextButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        url = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: url
                    }) { Text("Pegar") }
                }
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !audio, onClick = { audio = false }, label = { Text("🎬 Video") })
                FilterChip(selected = audio, onClick = { audio = true }, label = { Text("🎵 Audio") })
            }
        }
        if (!audio) {
            item {
                Text("Resolución", fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(144, 240, 360, 480, 720, 1080, 1440, 2160).forEach { h ->
                        val label = when (h) { 1440 -> "2K"; 2160 -> "4K UHD"; else -> "${h}p" }
                        FilterChip(selected = height == h, onClick = { height = h }, label = { Text(label) })
                    }
                }
            }
        } else {
            item {
                Text("Formato de audio", fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("mp3", "m4a", "opus", "ogg", "wav", "flac").forEach { f ->
                        FilterChip(selected = fmt == f, onClick = { fmt = f }, label = { Text(f.uppercase()) })
                    }
                }
                if (fmt in listOf("mp3", "m4a", "opus", "ogg")) {
                    Text("Calidad", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(128, 192, 320).forEach { k ->
                            FilterChip(selected = kbps == k, onClick = { kbps = k }, label = { Text("$k kbps") })
                        }
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    val u = url.trim()
                    if (!u.startsWith("http")) {
                        Toast.makeText(ctx, "Pega un enlace válido", Toast.LENGTH_SHORT).show()
                    } else {
                        Downloads.enqueue(u, audio, height, if (fmt == "ogg") "vorbis" else fmt, kbps)
                        Toast.makeText(ctx, "Añadido a la cola", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Descargar", fontSize = 16.sp) }
        }
        item {
            Text(
                "Úsala solo con contenido tuyo, libre o con permiso del autor.",
                fontSize = 12.sp, color = Color.Gray
            )
        }
        item {
            Text(Downloads.engineInfo.value, fontSize = 12.sp, color = Color.Gray)
            OutlinedButton(
                onClick = { Downloads.updateEngine() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Actualizar motor ahora") }
        }
        item {
            OutlinedButton(
                onClick = { cookiePicker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (hasCookies) "Cookies cargadas ✓ (cambiar)" else "Importar cookies.txt (si pide iniciar sesión)") }
        }
        if (jobs.isNotEmpty()) {
            item { Text("Cola de descargas", fontWeight = FontWeight.Bold) }
            items(jobs, key = { it.id }) { JobCard(it) }
        }
    }
}

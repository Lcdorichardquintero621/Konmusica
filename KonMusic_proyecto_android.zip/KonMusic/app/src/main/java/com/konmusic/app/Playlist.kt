package com.konmusic.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.DocumentsContract
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Lista de reproducción que el reproductor recorre en orden. */
object PlayQueue {
    var uris: List<Uri> = emptyList()
    var index = 0
}

/** Carpetas elegidas por el usuario y la playlist que sale de analizarlas. Se guarda en el teléfono. */
object Playlist {
    private lateinit var prefs: SharedPreferences
    val folders = mutableStateListOf<String>()
    val items = mutableStateListOf<Item>()
    val scanning = mutableStateOf(false)
    val status = mutableStateOf("")
    private val excluded = HashSet<String>()
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ui = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun init(app: Application) {
        prefs = app.getSharedPreferences("playlist", Context.MODE_PRIVATE)
        try {
            val f = JSONArray(prefs.getString("folders", "[]"))
            for (i in 0 until f.length()) folders.add(f.getString(i))
            val e = JSONArray(prefs.getString("excluded", "[]"))
            for (i in 0 until e.length()) excluded.add(e.getString(i))
            val it = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until it.length()) {
                val o = it.getJSONObject(i)
                items.add(
                    Item(
                        Uri.parse(o.getString("uri")), o.getString("name"), o.getString("ext"),
                        o.getLong("size"), o.getBoolean("video"), o.getLong("modified"), null,
                        o.optString("folder", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val f = JSONArray().also { a -> folders.forEach { a.put(it) } }
        val e = JSONArray().also { a -> excluded.forEach { a.put(it) } }
        val it = JSONArray().also { a ->
            items.forEach { x ->
                a.put(
                    JSONObject()
                        .put("uri", x.uri.toString()).put("name", x.name).put("ext", x.ext)
                        .put("size", x.size).put("video", x.video).put("modified", x.modified)
                        .put("folder", x.folder)
                )
            }
        }
        prefs.edit().putString("folders", f.toString()).putString("excluded", e.toString())
            .putString("items", it.toString()).apply()
    }

    fun folderLabel(s: String): String {
        val id = try { DocumentsContract.getTreeDocumentId(Uri.parse(s)) } catch (_: Exception) { s }
        val path = id.substringAfter(':', "")
        return if (path.isEmpty()) "Almacenamiento interno" else path
    }

    fun addFolder(app: Application, uri: Uri) {
        val s = uri.toString()
        if (s in folders) {
            status.value = "Esa carpeta ya está en la lista"
            return
        }
        folders.add(s)
        save()
        scan(app, listOf(s), replaceAll = false)
    }

    /** Vuelve a analizar todas las carpetas y recupera lo que se había quitado de la lista. */
    fun rescan(app: Application) {
        excluded.clear()
        scan(app, folders.toList(), replaceAll = true)
    }

    fun removeFolder(s: String) {
        folders.remove(s)
        items.removeAll { it.folder == s }
        save()
    }

    fun removeItem(i: Item) {
        items.remove(i)
        excluded.add(i.uri.toString())
        save()
    }

    private fun scan(app: Application, list: List<String>, replaceAll: Boolean) {
        scanning.value = true
        status.value = "Analizando..."
        io.launch {
            val found = ArrayList<Item>()
            for (f in list) {
                try { found += scanTree(app, Uri.parse(f), f) } catch (_: Exception) {}
            }
            val fresh = found.filter { it.uri.toString() !in excluded }
            ui.launch {
                if (replaceAll) items.clear() else items.removeAll { it.folder in list }
                items.addAll(fresh)
                items.sortWith(compareBy({ folders.indexOf(it.folder) }, { it.name.lowercase() }))
                scanning.value = false
                status.value = "${fresh.size} archivos encontrados"
                save()
            }
        }
    }

    private fun scanTree(app: Application, tree: Uri, folderKey: String): List<Item> {
        val out = ArrayList<Item>()
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        fun walk(docId: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            app.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        walk(id)
                    } else {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        val video = mime.startsWith("video") || ext in Downloads.videoExts
                        val audio = mime.startsWith("audio") || ext in Downloads.audioExts
                        if (video || audio) {
                            out.add(
                                Item(
                                    DocumentsContract.buildDocumentUriUsingTree(tree, id),
                                    name.substringBeforeLast('.'), ext, c.getLong(3),
                                    video && !mime.startsWith("audio"), c.getLong(4), null, folderKey
                                )
                            )
                        }
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree))
        return out
    }
}

package com.konmusic.app

import android.app.Application

class KonApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Downloads.init(this)
        Playlist.init(this)
    }
}

package com.konmusic.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun KonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2E7D32),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC8E6C9),
            onPrimaryContainer = Color(0xFF1B5E20),
            secondary = Color(0xFF66BB6A),
            secondaryContainer = Color(0xFFDCEDC8),
            background = Color(0xFFF1F8E9),
            surface = Color.White,
            surfaceVariant = Color(0xFFE8F5E9),
            onSurface = Color(0xFF1B2E1C)
        ),
        content = content
    )
}

// Verde hoja que se degrada hacia verde de hojas tiernas
val LeafGradient = Brush.horizontalGradient(
    listOf(Color(0xFF2E7D32), Color(0xFF5E9E34), Color(0xFF8BC34A))
)
val LeafBackground = Brush.verticalGradient(listOf(Color(0xFFF4FAEA), Color(0xFFDDEFC4)))

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(LeafGradient)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

package com.konmusic.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun KonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2E7D32),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC8E6C9),
            onPrimaryContainer = Color(0xFF1B5E20),
            secondary = Color(0xFF66BB6A),
            secondaryContainer = Color(0xFFDCEDC8),
            background = Color(0xFFF1F8E9),
            surface = Color.White,
            surfaceVariant = Color(0xFFE8F5E9),
            onSurface = Color(0xFF1B2E1C)
        ),
        content = content
    )
}

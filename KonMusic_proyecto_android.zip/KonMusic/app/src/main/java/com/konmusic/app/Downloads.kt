package com.konmusic.app

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class Job(
    val id: String,
    val url: String,
    val label: String,
    val progress: Float = 0f,
    val status: String = "En cola"
) {
    val active get() = status == "En cola" || status == "Descargando"
}

data class Item(
    val uri: Uri, val name: String, val ext: String, val size: Long,
    val video: Boolean, val modified: Long, val file: File?
)

private data class Req(
    val id: String, val url: String, val audio: Boolean,
    val height: Int, val format: String, val kbps: Int
)

object Downloads {
    lateinit var app: Application
    val jobs = mutableStateListOf<Job>()
    val version = mutableIntStateOf(0)

    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ui = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val queue = Channel<Req>(Channel.UNLIMITED)
    private val cancelled = HashSet<String>()
    private var initError: String? = null

    val videoExts = setOf("mp4", "mkv", "webm", "mov", "avi", "flv", "3gp", "ts", "wmv")
    val audioExts = setOf("mp3", "m4a", "opus", "ogg", "wav", "flac", "aac")

    val dir: File
        get() = File(app.getExternalFilesDir(null), "KonMusic").apply { mkdirs() }

    fun isVideo(f: File) = f.extension.lowercase() in videoExts

    private val mediaExts get() = videoExts + audioExts

    fun library(): List<Item> {
        val out = ArrayList<Item>()
        if (Build.VERSION.SDK_INT >= 29) {
            val uri = MediaStore.Files.getContentUri("external")
            val cols = arrayOf(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.MIME_TYPE
            )
            val sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
            try {
                app.contentResolver.query(uri, cols, sel, arrayOf("Movies/KonMusic%", "Music/KonMusic%"), null)?.use { c ->
                    while (c.moveToNext()) {
                        val full = c.getString(1) ?: continue
                        val ext = full.substringAfterLast('.', "").lowercase()
                        out.add(
                            Item(
                                ContentUris.withAppendedId(uri, c.getLong(0)),
                                full.substringBeforeLast('.'), ext, c.getLong(2),
                                (c.getString(4) ?: "").startsWith("video"), c.getLong(3) * 1000, null
                            )
                        )
                    }
                }
            } catch (_: Exception) {
            }
        } else {
            for (kind in listOf(Environment.DIRECTORY_MOVIES, Environment.DIRECTORY_MUSIC)) {
                val d = File(Environment.getExternalStoragePublicDirectory(kind), "KonMusic")
                d.listFiles()?.filter { it.isFile && it.extension.lowercase() in mediaExts }?.forEach {
                    out.add(Item(Uri.fromFile(it), it.nameWithoutExtension, it.extension.lowercase(),
                        it.length(), isVideo(it), it.lastModified(), it))
                }
            }
        }
        return out.sortedByDescending { it.modified }
    }

    fun deleteItem(i: Item): Boolean = try {
        if (i.file != null) i.file.delete() else app.contentResolver.delete(i.uri, null, null) > 0
    } catch (_: Exception) {
        false
    }

    private fun mimeFor(ext: String) = when (ext.lowercase()) {
        "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"
        "mov" -> "video/quicktime"; "avi" -> "video/x-msvideo"; "flv" -> "video/x-flv"
        "3gp" -> "video/3gpp"; "ts" -> "video/mp2t"; "wmv" -> "video/x-ms-wmv"
        "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "opus", "ogg" -> "audio/ogg"
        "wav" -> "audio/x-wav"; "flac" -> "audio/flac"; "aac" -> "audio/aac"
        else -> "application/octet-stream"
    }

    /** Mueve a Movies/KonMusic o Music/KonMusic los archivos terminados de la carpeta temporal. */
    private fun exportAll() {
        val files = dir.listFiles()?.filter { it.isFile } ?: return
        for (f in files) {
            if (f.extension.lowercase() !in mediaExts) { f.delete(); continue }
            val video = isVideo(f)
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(f.extension))
                        put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) "Movies" else "Music") + "/KonMusic")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val coll = if (video) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val uri = app.contentResolver.insert(coll, values) ?: continue
                    app.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    app.contentResolver.update(uri, values, null, null)
                } else {
                    val base = Environment.getExternalStoragePublicDirectory(
                        if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC
                    )
                    val d = File(base, "KonMusic").apply { mkdirs() }
                    val target = File(d, f.name)
                    f.copyTo(target, overwrite = true)
                    MediaScannerConnection.scanFile(app, arrayOf(target.absolutePath), null, null)
                }
                f.delete()
            } catch (_: Exception) {
            }
        }
    }

    fun init(a: Application) {
        app = a
        io.launch {
            try {
                YoutubeDL.getInstance().init(a)
                FFmpeg.getInstance().init(a)
            } catch (e: Exception) {
                initError = e.message ?: "No se pudo iniciar el motor"
            }
            // YouTube cambia seguido: actualiza yt-dlp (canal nightly) antes de descargar
            try {
                YoutubeDL.getInstance().updateYoutubeDL(a, YoutubeDL.UpdateChannel.NIGHTLY)
            } catch (_: Exception) {
            }
            for (r in queue) run(r)
        }
    }

    fun enqueue(url: String, audio: Boolean, height: Int, format: String, kbps: Int) {
        val id = UUID.randomUUID().toString()
        val label = if (audio) "Audio ${format.uppercase()}" else "Video ${height}p"
        ui.launch { jobs.add(Job(id, url, label)) }
        DownloadService.start(app)
        queue.trySend(Req(id, url, audio, height, format, kbps))
    }

    fun cancel(id: String) {
        cancelled.add(id)
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (_: Exception) {
        }
        update(id) { it.copy(status = "Cancelado") }
        checkIdle()
    }

    private fun update(id: String, f: (Job) -> Job) {
        ui.launch {
            val i = jobs.indexOfFirst { it.id == id }
            if (i >= 0) jobs[i] = f(jobs[i])
        }
    }

    private fun checkIdle() {
        ui.launch {
            if (jobs.none { it.active }) app.stopService(Intent(app, DownloadService::class.java))
        }
    }

    val cookiesFile: File get() = File(app.filesDir, "cookies.txt")

    private fun buildRequest(r: Req, client: String?): YoutubeDLRequest {
        val req = YoutubeDLRequest(r.url)
        req.addOption("--no-playlist")
        req.addOption("-o", dir.absolutePath + "/%(title).100s.%(ext)s")
        if (cookiesFile.exists()) req.addOption("--cookies", cookiesFile.absolutePath)
        if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
        if (r.audio) {
            req.addOption("-x")
            req.addOption("--audio-format", r.format)
            if (r.format in listOf("mp3", "m4a", "opus", "vorbis")) {
                req.addOption("--audio-quality", "${r.kbps}K")
            }
        } else {
            req.addOption("-f", "bv*[height<=${r.height}]+ba/b[height<=${r.height}]/b")
            req.addOption("--merge-output-format", "mp4/mkv")
        }
        return req
    }

    private fun run(r: Req) {
        if (r.id in cancelled) return
        if (initError != null) {
            update(r.id) { it.copy(status = "Error: $initError") }
            checkIdle()
            return
        }
        update(r.id) { it.copy(status = "Descargando") }
        var lastError = "falló"
        // Si YouTube pide iniciar sesión, reintenta con otros clientes de reproducción
        for (client in listOf<String?>(null, "android_vr", "tv", "web_safari")) {
            if (r.id in cancelled) break
            try {
                YoutubeDL.getInstance().execute(buildRequest(r, client), r.id) { p, _, _ ->
                    update(r.id) { it.copy(progress = (p / 100f).coerceIn(0f, 1f)) }
                }
                update(r.id) { it.copy(progress = 1f, status = "Guardando...") }
                exportAll()
                update(r.id) { it.copy(status = "Completado") }
                ui.launch { version.intValue++ }
                checkIdle()
                return
            } catch (e: Exception) {
                val lines = (e.message ?: "falló").lines().filter { it.isNotBlank() }
                lastError = lines.lastOrNull { it.contains("ERROR") } ?: lines.lastOrNull() ?: "falló"
                val retry = lastError.contains("sign in", true) || lastError.contains("bot", true) ||
                    lastError.contains("not available", true) || lastError.contains("403")
                if (!retry) break
            }
        }
        if (r.id in cancelled) {
            update(r.id) { it.copy(status = "Cancelado") }
        } else {
            update(r.id) { it.copy(status = "Error: ${lastError.take(160)}") }
        }
        checkIdle()
    }
}

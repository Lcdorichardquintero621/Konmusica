package com.konmusic.app

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class Job(
    val id: String,
    val url: String,
    val label: String,
    val progress: Float = 0f,
    val status: String = "En cola"
) {
    val active get() = status == "En cola" || status == "Descargando"
}

private data class Req(
    val id: String, val url: String, val audio: Boolean,
    val height: Int, val format: String, val kbps: Int
)

object Downloads {
    lateinit var app: Application
    val jobs = mutableStateListOf<Job>()
    val version = mutableIntStateOf(0)

    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ui = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val queue = Channel<Req>(Channel.UNLIMITED)
    private val cancelled = HashSet<String>()
    private var initError: String? = null

    val videoExts = setOf("mp4", "mkv", "webm", "mov", "avi", "flv", "3gp", "ts", "wmv")
    val audioExts = setOf("mp3", "m4a", "opus", "ogg", "wav", "flac", "aac")

    val dir: File
        get() = File(app.getExternalFilesDir(null), "KonMusic").apply { mkdirs() }

    fun isVideo(f: File) = f.extension.lowercase() in videoExts

    fun library(): List<File> =
        dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in (videoExts + audioExts) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun init(a: Application) {
        app = a
        io.launch {
            try {
                YoutubeDL.getInstance().init(a)
                FFmpeg.getInstance().init(a)
            } catch (e: Exception) {
                initError = e.message ?: "No se pudo iniciar el motor"
            }
            // YouTube cambia seguido: actualiza yt-dlp (canal nightly) antes de descargar
            try {
                YoutubeDL.getInstance().updateYoutubeDL(a, YoutubeDL.UpdateChannel.NIGHTLY)
            } catch (_: Exception) {
            }
            for (r in queue) run(r)
        }
    }

    fun enqueue(url: String, audio: Boolean, height: Int, format: String, kbps: Int) {
        val id = UUID.randomUUID().toString()
        val label = if (audio) "Audio ${format.uppercase()}" else "Video ${height}p"
        ui.launch { jobs.add(Job(id, url, label)) }
        DownloadService.start(app)
        queue.trySend(Req(id, url, audio, height, format, kbps))
    }

    fun cancel(id: String) {
        cancelled.add(id)
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (_: Exception) {
        }
        update(id) { it.copy(status = "Cancelado") }
        checkIdle()
    }

    private fun update(id: String, f: (Job) -> Job) {
        ui.launch {
            val i = jobs.indexOfFirst { it.id == id }
            if (i >= 0) jobs[i] = f(jobs[i])
        }
    }

    private fun checkIdle() {
        ui.launch {
            if (jobs.none { it.active }) app.stopService(Intent(app, DownloadService::class.java))
        }
    }

    val cookiesFile: File get() = File(app.filesDir, "cookies.txt")

    private fun buildRequest(r: Req, client: String?): YoutubeDLRequest {
        val req = YoutubeDLRequest(r.url)
        req.addOption("--no-playlist")
        req.addOption("-o", dir.absolutePath + "/%(title).100s.%(ext)s")
        if (cookiesFile.exists()) req.addOption("--cookies", cookiesFile.absolutePath)
        if (client != null) req.addOption("--extractor-args", "youtube:player_client=$client")
        if (r.audio) {
            req.addOption("-x")
            req.addOption("--audio-format", r.format)
            if (r.format in listOf("mp3", "m4a", "opus", "vorbis")) {
                req.addOption("--audio-quality", "${r.kbps}K")
            }
        } else {
            req.addOption("-f", "bv*[height<=${r.height}]+ba/b[height<=${r.height}]/b")
            req.addOption("--merge-output-format", "mp4/mkv")
        }
        return req
    }

    private fun run(r: Req) {
        if (r.id in cancelled) return
        if (initError != null) {
            update(r.id) { it.copy(status = "Error: $initError") }
            checkIdle()
            return
        }
        update(r.id) { it.copy(status = "Descargando") }
        var lastError = "falló"
        // Si YouTube pide iniciar sesión, reintenta con otros clientes de reproducción
        for (client in listOf<String?>(null, "android_vr", "tv", "web_safari")) {
            if (r.id in cancelled) break
            try {
                YoutubeDL.getInstance().execute(buildRequest(r, client), r.id) { p, _, _ ->
                    update(r.id) { it.copy(progress = (p / 100f).coerceIn(0f, 1f)) }
                }
                update(r.id) { it.copy(progress = 1f, status = "Completado") }
                ui.launch { version.intValue++ }
                checkIdle()
                return
            } catch (e: Exception) {
                val lines = (e.message ?: "falló").lines().filter { it.isNotBlank() }
                lastError = lines.lastOrNull { it.contains("ERROR") } ?: lines.lastOrNull() ?: "falló"
                val retry = lastError.contains("sign in", true) || lastError.contains("bot", true) ||
                    lastError.contains("not available", true) || lastError.contains("403")
                if (!retry) break
            }
        }
        if (r.id in cancelled) {
            update(r.id) { it.copy(status = "Cancelado") }
        } else {
            update(r.id) { it.copy(status = "Error: ${lastError.take(160)}") }
        }
        checkIdle()
    }
}

package com.konmusic.app

import android.app.PictureInPictureParams
import android.graphics.drawable.ColorDrawable
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.provider.OpenableColumns
import android.util.Rational
import androidx.core.content.ContextCompat
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class PlayerActivity : ComponentActivity() {
    private lateinit var vlc: LibVLC
    private lateinit var player: MediaPlayer
    private var pfd: ParcelFileDescriptor? = null
    private lateinit var key: String
    private var isVideo = false
    private var title by mutableStateOf("KonMusic")
    private var uris: List<Uri> = emptyList()
    private var index by mutableIntStateOf(0)
    private var layout: VLCVideoLayout? = null
    private var attached = false
    private var resumeOnStart = false
    private var resumeOnGain = false
    private var lastNotifPlaying = true
    private var inPip by mutableStateOf(false)
    private lateinit var am: AudioManager
    private var focusReq: AudioFocusRequest? = null

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeOnGain = false; player.pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (player.isPlaying) { resumeOnGain = true; player.pause() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player.volume = 30
            AudioManager.AUDIOFOCUS_GAIN -> {
                player.volume = 100
                if (resumeOnGain) { resumeOnGain = false; player.play() }
            }
        }
    }

    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                MediaService.ACTION_TOGGLE -> if (player.isPlaying) player.pause() else player.play()
                MediaService.ACTION_STOP -> finish()
                AudioManager.ACTION_AUDIO_BECOMING_NOISY -> player.pause()
            }
        }
    }

    private fun requestFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build()
                )
                .setOnAudioFocusChangeListener(focusListener).build()
            focusReq = r
            am.requestAudioFocus(r)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
    }

    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) focusReq?.let { am.abandonAudioFocusRequest(it) }
        else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(focusListener)
        }
    }

    private fun attach() {
        val l = layout ?: return
        if (!attached) {
            player.attachViews(l, null, false, false)
            attached = true
        }
    }

    private fun detach() {
        if (attached) {
            player.detachViews()
            attached = false
        }
    }

    private fun nameOf(uri: Uri): String = try {
        if (uri.scheme == "content") {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: "KonMusic"
        } else File(uri.path ?: "").name
    } catch (_: Exception) {
        "KonMusic"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Dibuja el video hasta los bordes (incluida la zona de la cámara) y fondo negro
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.BLACK))
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        if (intent.getBooleanExtra("queue", false) && PlayQueue.uris.isNotEmpty()) {
            uris = PlayQueue.uris
            index = PlayQueue.index.coerceIn(0, uris.size - 1)
        } else {
            uris = listOf(intent.data ?: Uri.fromFile(File(intent.getStringExtra("path") ?: "")))
            index = 0
        }
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        vlc = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        player = MediaPlayer(vlc)
        loadCurrent()
        // Al terminar una pista pasa sola a la siguiente de la lista
        player.setEventListener(MediaPlayer.EventListener { e ->
            if (e.type == MediaPlayer.Event.EndReached) runOnUiThread { next() }
        })

        val f = IntentFilter().apply {
            addAction(MediaService.ACTION_TOGGLE)
            addAction(MediaService.ACTION_STOP)
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        }
        ContextCompat.registerReceiver(this, controlReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        requestFocus()
        if (isVideo) {
            if (Build.VERSION.SDK_INT >= 31) {
                setPictureInPictureParams(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9)).setAutoEnterEnabled(true).build()
                )
            }
        } else {
            // La música sigue sonando al salir de la app
            MediaService.show(this, title)
        }
        setContent { KonTheme { PlayerScreen() } }
    }

    private fun loadCurrent() {
        val uri = uris[index]
        key = uri.toString()
        title = nameOf(uri)
        isVideo = if (uri.scheme == "content") {
            (contentResolver.getType(uri) ?: "").startsWith("video")
        } else File(uri.path ?: "").extension.lowercase() in Downloads.videoExts
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        val media = if (uri.scheme == "content") {
            pfd = contentResolver.openFileDescriptor(uri, "r")
            Media(vlc, pfd!!.fileDescriptor)
        } else {
            Media(vlc, uri)
        }
        player.media = media
        media.release()
    }

    private fun applyType(wasVideo: Boolean) {
        if (isVideo) {
            if (!wasVideo) MediaService.hide(this)
            attach()
        } else {
            if (wasVideo) MediaService.show(this, title) else MediaService.update(this, title, true)
            lastNotifPlaying = true
        }
    }

    private fun saveResume() {
        val resume = if (player.length - player.time < 5000) 0L else player.time
        getSharedPreferences("pos", MODE_PRIVATE).edit().putLong(key, resume).apply()
    }

    private fun next() {
        if (index >= uris.size - 1) return
        val was = isVideo
        saveResume()
        index++
        try {
            loadCurrent()
        } catch (_: Exception) {
            next() // si un archivo ya no existe, salta al siguiente
            return
        }
        player.play()
        applyType(was)
    }

    private fun prev() {
        if (player.time > 3000 || index == 0) {
            player.time = 0
            return
        }
        val was = isVideo
        saveResume()
        index--
        try {
            loadCurrent()
        } catch (_: Exception) {
            return
        }
        player.play()
        applyType(was)
    }

    private fun fmt(ms: Long): String {
        val s = ms.coerceAtLeast(0) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun loadSub(u: Uri) {
        try {
            val f = File(cacheDir, "sub_${System.currentTimeMillis()}.srt")
            contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            player.addSlave(IMedia.Slave.Type.Subtitle, Uri.fromFile(f), true)
        } catch (_: Exception) {
        }
    }

    private fun setFullscreen(on: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            if (Build.VERSION.SDK_INT >= 28) {
                window.attributes = window.attributes.also {
                    it.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun PlayerScreen() {
        var playing by remember { mutableStateOf(true) }
        var pos by remember { mutableFloatStateOf(0f) }
        var seeking by remember { mutableStateOf(false) }
        var timeText by remember { mutableStateOf("0:00 / 0:00") }
        var speed by remember { mutableFloatStateOf(1f) }
        var menu by remember { mutableStateOf(false) }
        var show by remember { mutableStateOf(true) }
        var full by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val orientation = LocalConfiguration.current.orientation
        val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
            u?.let { loadSub(it) }
        }

        // Al girar el teléfono a horizontal entra en pantalla completa; en vertical sale
        LaunchedEffect(orientation) { full = orientation == Configuration.ORIENTATION_LANDSCAPE }
        LaunchedEffect(full) { setFullscreen(full) }
        // Oculta los controles solos mientras reproduce
        LaunchedEffect(show, playing, seeking) {
            if (show && playing && !seeking) {
                delay(4000)
                show = false
            }
        }
        LaunchedEffect(Unit) {
            val saved = getSharedPreferences("pos", MODE_PRIVATE).getLong(key, 0L)
            delay(700)
            if (saved > 5000) player.time = saved
            while (true) {
                val len = player.length
                val t = player.time
                if (len > 0 && !seeking) pos = t.toFloat() / len
                timeText = "${fmt(t)} / ${fmt(len)}"
                playing = player.isPlaying
                if (!isVideo && playing != lastNotifPlaying) {
                    lastNotifPlaying = playing
                    MediaService.update(this@PlayerActivity, title, playing)
                }
                delay(400)
            }
        }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    VLCVideoLayout(c).also {
                        layout = it
                        attach()
                        player.play()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            // Capa transparente: un toque muestra u oculta los controles
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { show = !show }
            )
            if (show && !inPip) {
                Column(
                    Modifier.align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xE61B5E20), Color(0xE63B6E22))))
                        .navigationBarsPadding()
                        .displayCutoutPadding()
                        .padding(12.dp)
                ) {
                    Text(
                        title, color = Color.White, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Slider(
                        value = pos,
                        onValueChange = { seeking = true; pos = it },
                        onValueChangeFinished = {
                            player.time = (pos * player.length).toLong(); seeking = false
                        }
                    )
                    Text(timeText, color = Color.White, fontSize = 12.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CtrlButton("⏪ 10 s") { player.time = maxOf(0L, player.time - 10000) }
                        CtrlButton(if (playing) "⏸  Pausa" else "▶  Reproducir") {
                            if (player.isPlaying) player.pause() else player.play()
                        }
                        CtrlButton("10 s ⏩") { player.time = player.time + 10000 }
                    }
                    if (uris.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CtrlButton("⏮ Anterior", small = true) { prev() }
                            Text("${index + 1} / ${uris.size}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            CtrlButton("Siguiente ⏭", small = true) { next() }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                    ) {
                        listOf(0.5f, 1f, 1.5f, 2f).forEach { s ->
                            CtrlButton("${s}x", selected = speed == s, small = true) { speed = s; player.rate = s }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    FlowRow(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CtrlButton(if (full) "⛶ Salir" else "⛶ Pantalla completa", small = true) { full = !full }
                        CtrlButton("🔄 Girar", small = true) {
                            scope.launch {
                                val land = resources.configuration.orientation ==
                                    Configuration.ORIENTATION_LANDSCAPE
                                requestedOrientation = if (land)
                                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                delay(1500)
                                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                            }
                        }
                        CtrlButton("🔊 Audio", small = true) { menu = true }
                        CtrlButton("💬 Subtítulos", small = true) { subPicker.launch(arrayOf("*/*")) }
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        (player.audioTracks ?: emptyArray()).forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t.name) },
                                onClick = { player.audioTrack = t.id; menu = false }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        if (Build.VERSION.SDK_INT >= 26 && isVideo) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun onStart() {
        super.onStart()
        if (isVideo) {
            attach() // vuelve a conectar la imagen al regresar a la app
            if (resumeOnStart) {
                resumeOnStart = false
                player.play()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // El video no sigue en segundo plano (solo en miniatura); la música sí
        if (isVideo) {
            if (player.isPlaying) {
                resumeOnStart = true
                player.pause()
            }
            detach()
        }
    }

    override fun onDestroy() {
        saveResume()
        try { unregisterReceiver(controlReceiver) } catch (_: Exception) {}
        abandonFocus()
        if (!isVideo) MediaService.hide(this)
        player.stop()
        detach()
        player.release()
        vlc.release()
        pfd?.close()
        super.onDestroy()
    }
}

@Composable
private fun CtrlButton(text: String, selected: Boolean = false, small: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(
                if (selected) SolidColor(Color.White)
                else Brush.horizontalGradient(listOf(Color(0xFF388E3C), Color(0xFF7CB342)))
            )
            .clickable(onClick = onClick)
            .padding(horizontal = if (small) 10.dp else 14.dp, vertical = if (small) 6.dp else 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = if (small) 12.sp else 15.sp, fontWeight = FontWeight.Bold,
            color = if (selected) Color(0xFF1B5E20) else Color.White
        )
    }
}

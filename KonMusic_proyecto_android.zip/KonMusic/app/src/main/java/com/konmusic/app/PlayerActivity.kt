package com.konmusic.app

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class PlayerActivity : ComponentActivity() {
    private lateinit var vlc: LibVLC
    private lateinit var player: MediaPlayer
    private var pfd: ParcelFileDescriptor? = null
    private lateinit var key: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uri: Uri = intent.data ?: Uri.fromFile(File(intent.getStringExtra("path") ?: ""))
        key = uri.toString()
        vlc = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        player = MediaPlayer(vlc)
        val media = if (uri.scheme == "content") {
            pfd = contentResolver.openFileDescriptor(uri, "r")
            Media(vlc, pfd!!.fileDescriptor)
        } else {
            Media(vlc, uri)
        }
        player.media = media
        media.release()
        setContent { KonTheme { PlayerScreen() } }
    }

    private fun fmt(ms: Long): String {
        val s = ms.coerceAtLeast(0) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun loadSub(u: Uri) {
        try {
            val f = File(cacheDir, "sub_${System.currentTimeMillis()}.srt")
            contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            player.addSlave(IMedia.Slave.Type.Subtitle, Uri.fromFile(f), true)
        } catch (_: Exception) {
        }
    }

    private fun setFullscreen(on: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            if (Build.VERSION.SDK_INT >= 28) {
                window.attributes = window.attributes.also {
                    it.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun PlayerScreen() {
        var playing by remember { mutableStateOf(true) }
        var pos by remember { mutableFloatStateOf(0f) }
        var seeking by remember { mutableStateOf(false) }
        var timeText by remember { mutableStateOf("0:00 / 0:00") }
        var speed by remember { mutableFloatStateOf(1f) }
        var menu by remember { mutableStateOf(false) }
        var show by remember { mutableStateOf(true) }
        var full by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val orientation = LocalConfiguration.current.orientation
        val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
            u?.let { loadSub(it) }
        }

        // Al girar el teléfono a horizontal entra en pantalla completa; en vertical sale
        LaunchedEffect(orientation) { full = orientation == Configuration.ORIENTATION_LANDSCAPE }
        LaunchedEffect(full) { setFullscreen(full) }
        // Oculta los controles solos mientras reproduce
        LaunchedEffect(show, playing, seeking) {
            if (show && playing && !seeking) {
                delay(4000)
                show = false
            }
        }
        LaunchedEffect(Unit) {
            val saved = getSharedPreferences("pos", MODE_PRIVATE).getLong(key, 0L)
            delay(700)
            if (saved > 5000) player.time = saved
            while (true) {
                val len = player.length
                val t = player.time
                if (len > 0 && !seeking) pos = t.toFloat() / len
                timeText = "${fmt(t)} / ${fmt(len)}"
                playing = player.isPlaying
                delay(400)
            }
        }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    VLCVideoLayout(c).also {
                        player.attachViews(it, null, false, false)
                        player.play()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            // Capa transparente: un toque muestra u oculta los controles
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { show = !show }
            )
            if (show) {
                Column(
                    Modifier.align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color(0xCC1B5E20))
                        .navigationBarsPadding()
                        .padding(12.dp)
                ) {
                    Slider(
                        value = pos,
                        onValueChange = { seeking = true; pos = it },
                        onValueChangeFinished = {
                            player.time = (pos * player.length).toLong(); seeking = false
                        }
                    )
                    Text(timeText, color = Color.White, fontSize = 12.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { player.time = maxOf(0L, player.time - 10000) }) {
                            Text("⏪ 10", color = Color.White)
                        }
                        Button(onClick = { if (player.isPlaying) player.pause() else player.play() }) {
                            Text(if (playing) "⏸" else "▶")
                        }
                        TextButton(onClick = { player.time = player.time + 10000 }) {
                            Text("10 ⏩", color = Color.White)
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0.5f, 1f, 1.5f, 2f).forEach { s ->
                            FilterChip(
                                selected = speed == s,
                                onClick = { speed = s; player.rate = s },
                                label = { Text("${s}x") }
                            )
                        }
                        AssistChip(
                            onClick = { full = !full },
                            label = { Text(if (full) "⛶ Salir" else "⛶ Pantalla completa") }
                        )
                        AssistChip(
                            onClick = {
                                scope.launch {
                                    val land = resources.configuration.orientation ==
                                        Configuration.ORIENTATION_LANDSCAPE
                                    requestedOrientation = if (land)
                                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                    delay(1500)
                                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                                }
                            },
                            label = { Text("🔄 Girar") }
                        )
                        AssistChip(onClick = { menu = true }, label = { Text("Audio") })
                        AssistChip(onClick = { subPicker.launch(arrayOf("*/*")) }, label = { Text("Subtítulos") })
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        (player.audioTracks ?: emptyArray()).forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t.name) },
                                onClick = { player.audioTrack = t.id; menu = false }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        if (Build.VERSION.SDK_INT >= 26 && player.videoTracksCount > 0) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isInPictureInPictureMode && player.videoTracksCount > 0) player.pause()
    }

    override fun onDestroy() {
        val resume = if (player.length - player.time < 5000) 0L else player.time
        getSharedPreferences("pos", MODE_PRIVATE).edit().putLong(key, resume).apply()
        player.stop()
        player.detachViews()
        player.release()
        vlc.release()
        pfd?.close()
        super.onDestroy()
    }
}

package com.konmusic.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Mantiene viva la app mientras suena música en segundo plano. */
class MediaService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title") ?: "KonMusic"
        val playing = intent?.getBooleanExtra("playing", true) ?: true
        val n = build(this, title, playing)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        return START_NOT_STICKY
    }

    companion object {
        const val NOTIF_ID = 2
        const val ACTION_TOGGLE = "com.konmusic.app.TOGGLE"
        const val ACTION_STOP = "com.konmusic.app.STOP"

        fun build(c: Context, title: String, playing: Boolean): Notification {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("media", "Reproducción", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val imm = PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(
                c, 0,
                Intent(c, PlayerActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                imm or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val toggle = PendingIntent.getBroadcast(
                c, 1, Intent(ACTION_TOGGLE).setPackage(c.packageName), imm
            )
            val stop = PendingIntent.getBroadcast(
                c, 2, Intent(ACTION_STOP).setPackage(c.packageName), imm
            )
            return NotificationCompat.Builder(c, "media")
                .setContentTitle(title)
                .setContentText(if (playing) "Reproduciendo" else "En pausa")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(open)
                .setOngoing(playing)
                .addAction(0, if (playing) "Pausa" else "Reproducir", toggle)
                .addAction(0, "Cerrar", stop)
                .build()
        }

        fun show(c: Context, title: String) {
            try {
                ContextCompat.startForegroundService(
                    c, Intent(c, MediaService::class.java).putExtra("title", title).putExtra("playing", true)
                )
            } catch (_: Exception) {
            }
        }

        fun update(c: Context, title: String, playing: Boolean) {
            try {
                c.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(c, title, playing))
            } catch (_: Exception) {
            }
        }

        fun hide(c: Context) {
            c.stopService(Intent(c, MediaService::class.java))
        }
    }
}

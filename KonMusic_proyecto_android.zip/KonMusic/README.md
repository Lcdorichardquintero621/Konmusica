# KonMusic

App Android para descargar video (144p a 4K) y audio (MP3, M4A, OPUS, OGG, WAV, FLAC),
con biblioteca sin conexión y reproductor integrado (libVLC).

## Compilar el APK (GitHub)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. Ve a Actions > "Build APK" > Run workflow (o haz push a `main`).
3. Cuando termine, descarga el artefacto **KonMusic-APK** e instala el APK en tu teléfono.

Úsala solo con contenido tuyo, libre o con permiso del autor.
